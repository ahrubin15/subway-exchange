# MTA Feed Research / Archival

No live collector is running yet. Raw or historical observations belong in object storage rather than committed Git files. Archive source timestamps, fetch times, coverage and route/direction/trip/stop IDs. A blank response is not automatically evidence of NO departures.
