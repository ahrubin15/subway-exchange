# Frontend

The root `../index.html` remains the current GitHub Pages entrypoint. When we modularize, preserve the approved behavior and add production API integration behind a configuration boundary.
