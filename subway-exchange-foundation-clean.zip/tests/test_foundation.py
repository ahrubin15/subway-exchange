import hashlib
import pathlib
import re
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


class FoundationTests(unittest.TestCase):
    def test_root_site_entrypoint(self):
        html = (ROOT / 'index.html').read_text(encoding='utf-8')
        self.assertRegex(html.lower(), r'<!doctype html>')
        self.assertIn('<title>', html)
        self.assertIn('<script', html)

    def test_approved_design_snapshot_unchanged(self):
        deployed = (ROOT / 'index.html').read_bytes()
        approved = (ROOT / 'docs/design/v0.6.1.html').read_bytes()
        self.assertEqual(hashlib.sha256(deployed).digest(), hashlib.sha256(approved).digest())

    def test_project_directories_present(self):
        for name in ('frontend', 'backend', 'data', 'tests', 'docs'):
            with self.subTest(directory=name):
                self.assertTrue((ROOT / name).is_dir())

    def test_no_obvious_demo_claim_of_live_data(self):
        html = (ROOT / 'index.html').read_text(encoding='utf-8')
        self.assertIn('DEMO', html.upper())


if __name__ == '__main__':
    unittest.main()
