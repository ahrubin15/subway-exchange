# Backend — Not Implemented Yet

Planned API concerns: session/identity, market list and quote, prediction acceptance, account balance and ledger, Portfolio tickets, league membership, settlement evidence, notifications, feedback.

Do not add simulated security endpoints or public API routes that could be mistaken for production services.
