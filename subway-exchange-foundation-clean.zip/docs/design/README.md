# Approved Design Baseline

`v0.6.1.html` is an **unchanged** reference copy of the approved interactive front-end.

SHA-256: `84f89b33af6e3f6d8e70d1d1d95b999d5e3966f1c5133480a76113be03987cd6`

The root `index.html` is identical to this reference in the starter package.
Do not silently replace the approved visuals or claim browser-local demo wallets are production-safe.
A future Git tag `design-v0.6.1` can be created **after** this is committed in the GitHub repo.
