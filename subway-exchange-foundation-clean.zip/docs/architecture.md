# Architecture Decision Record — Proposed, Not Yet Deployed

## Constraints

- Monthly recurring platform budget **at most $100 USD**; start free where technically safe.
- First users: owner alpha, followed by invitation-only friends and family.
- Continuous MTA feed capture and settlement must run while no player is online.
- Reuse existing GitHub Pages demo until API integration requires a change.
- No real money, token purchase, transfer, redemption, or prizes.

## Lean Candidate Stack (Subject to Pricing and Runtime Verification)

| Concern | Candidate | Decision |
|---|---|---|
| Source & CI | GitHub + GitHub Actions | Existing repo; setup package prepared |
| Frontend | Existing GitHub Pages first | Keep current live demo unchanged |
| API / scheduled jobs | Cloudflare Workers or small hosted Python service | OPEN: inspect GTFS decoder/runtime/cron limits |
| Relational DB / auth | Supabase PostgreSQL + Auth | OPEN: security and write-throughput tests |
| Raw feed archival | Compressed object storage | OPEN: storage budget and retention |
| Owner analytics | Read-only SQL-backed dashboard | Future |

## Key Boundaries

1. Browser can request quotes and submit intent but never award tokens or choose outcomes.
2. Backend issues immutable market versions and signed/server-confirmed quotes with expiry.
3. Atomic token ledger enforces available balances, per-player/per-market caps, and idempotency.
4. Feed collector stores source timestamps and gaps; no trustworthy evidence means wait or VOID, never fabricated NO.
5. Separate quote/market/settlement states from user notification records.
6. Keep context-aware event overrides audit-logged, not arbitrary odds edits.

## Pre-Approval Checklist

- [ ] Verify current provider terms, pricing, cron and CPU allowances.
- [ ] Test MTA GTFS-RT decode and network requests in selected runtime.
- [ ] Estimate archive volume from a 24-hour real collection.
- [ ] Compare free-tier reliability and costs with $100 ceiling; select provider.
- [ ] Confirm credential ownership and access recovery.
- [ ] Set real billing alerts in provider consoles (not just documentation).
