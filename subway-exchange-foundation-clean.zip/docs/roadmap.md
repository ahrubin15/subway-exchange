# Engineering Checklist — Start Here

Legend: `[x]` = done in this local starter package; `[ ]` = not yet completed in your GitHub account or cloud.

## Phase 1 — Foundation

- [x] Prepare repo folder organization: frontend, backend, data, tests, docs (starter archive).
- [x] Preserve an unchanged reference copy of approved v0.6.1.
- [x] Prepare first automated code checks.
- [ ] Commit the foundation into your actual GitHub repository.
- [ ] Create an actual Git tag `design-v0.6.1` in GitHub.
- [ ] Choose services for API, job scheduler, DB and accounts after validation.
- [ ] Create development/staging settings separately from production.
- [ ] Configure GitHub branch protection and repo secrets (where available).
- [ ] Create database, backups and billing alerts with actual provider accounts.
- [ ] Verify GitHub Pages build remains green after commit.

## Phase 2 — Live MTA Collector

- [ ] Confirm terms and fetch GTFS static and realtime sample.
- [ ] Implement route/trip/direction/stop decoding.
- [ ] Build scheduled reliable collector, freshness checks and archive.
- [ ] Record ingestion coverage and exceptions.

## Phase 3 — Market Evidence & Shadow Mode

- [ ] Revalidate exact frozen market templates.
- [ ] Run future-only markets with publication-time feature snapshots.
- [ ] Measure YES/NO/VOID and settlement delay; restrict risky templates.

## Phase 4 — Market Engine and Wallet

- [ ] Automated candidate generation, pricing, qualification and diversification.
- [ ] Secure quotes, client order intent, immutable acceptance.
- [ ] Atomic Token ledger, grants, exposure checks and idempotent settlement.
- [ ] Source-coverage pause, audit evidence and VOID/refunds.

## Phase 5 — Product Integration & Friends Beta

- [ ] Connect existing UI to actual server API and settlement.
- [ ] Guest-to-saved accounts, privacy and deletion.
- [ ] Shared basic Crews, code invitations, leaderboards.
- [ ] Server-backed feedback, notifications and founder analytics.
- [ ] Legal/data rights, security, backup, monitoring and beta scale tests.
